const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./pos.db');

db.serialize(() => {
  db.run('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)');
  db.run('CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL)');

  db.run('DELETE FROM users');
  db.run('INSERT INTO users (username, password) VALUES ("Rony", "258025")');

  db.run('DELETE FROM products');
  const sample = [
    ['Baby Frock', 480],
    ['Mens Shirt', 750],
    ['Levis Jeans', 1200],
    ['Red Dress', 950],
    ['Nike T-Shirt', 650]
  ];
  const stmt = db.prepare('INSERT INTO products (name, price) VALUES (?, ?)');
  sample.forEach(p => stmt.run(p[0], p[1]));
  stmt.finalize();
});

db.close();

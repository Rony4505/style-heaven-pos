const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
const app = express();
app.use(cors());
app.use(express.json());

const SECRET = process.env.JWT_SECRET || 'styleheaven_secret';
const db = new sqlite3.Database('./pos.db');

app.get('/', (req, res) => res.send('Style Heaven POS API Running'));

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
    if (row) {
      const token = jwt.sign({ id: row.id, username: row.username }, SECRET, { expiresIn: '1d' });
      res.json({ success: true, token });
    } else res.status(401).json({ success: false, message: 'Invalid credentials' });
  });
});

app.get('/products', (req, res) => {
  db.all('SELECT * FROM products', [], (err, rows) => res.json(rows));
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

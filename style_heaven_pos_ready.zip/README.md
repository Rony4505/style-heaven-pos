# Style Heaven POS (Mobile Ready)

### Default Login
- Username: Rony
- Password: 258025

### Backend (Render)
- Root: `server`
- Build: `npm install && node init_db.js`
- Start: `node index.js`
- Env: `JWT_SECRET=styleheaven_secret`

### Frontend (Vercel)
- Root: `client`
- Env: `VITE_API_BASE=[Render API URL]`

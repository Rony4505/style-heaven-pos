import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080';

export default function App() {
  const [products, setProducts] = useState([]);
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => { if (user) loadProducts(); }, [user]);

  const login = async () => {
    try {
      const res = await axios.post(`${API}/login`, { username, password });
      if (res.data.success) {
        setUser(res.data);
        alert('Login successful');
      }
    } catch {
      alert('Invalid login');
    }
  };

  const loadProducts = async () => {
    const res = await axios.get(`${API}/products`);
    setProducts(res.data);
  };

  if (!user)
    return (
      <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
        <h2>Style Heaven POS Login</h2>
        <input placeholder="Username" onChange={e => setUsername(e.target.value)} />
        <br />
        <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} />
        <br />
        <button onClick={login}>Login</button>
      </div>
    );

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h2>🛍️ Style Heaven POS</h2>
      <p>Currency: টাকা</p>
      <ul>
        {products.map(p => (
          <li key={p.id}>{p.name} — ৳{p.price}</li>
        ))}
      </ul>
    </div>
  );
}
